from enum import Enum


class JobStatus(str, Enum):
    queued = "queued"
    retrieving_sources = "retrieving_sources"
    fetching_documents = "fetching_documents"
    building_knowledge_base = "building_knowledge_base"
    drafting_report = "drafting_report"
    verifying_claims = "verifying_claims"
    finalizing = "finalizing"
    completed = "completed"
    failed = "failed"