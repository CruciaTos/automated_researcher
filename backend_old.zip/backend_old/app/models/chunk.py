from sqlalchemy import Column, ForeignKey, Integer, JSON, Text

from .base import Base


class Chunk(Base):
    __tablename__ = "chunks"

    id = Column(Integer, primary_key=True, index=True)
    document_id = Column(Integer, ForeignKey("documents.id"), nullable=False, index=True)
    text = Column(Text, nullable=False)
    embedding = Column(JSON, nullable=True)