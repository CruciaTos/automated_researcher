from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from ..config import SQLALCHEMY_DATABASE_URL

# Use the same database URL as defined in config.py
DATABASE_URL = SQLALCHEMY_DATABASE_URL

# Engine creation (SQLite example; adjust connect_args for other DBs if needed)
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})

# Session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base class for declarative models
Base = declarative_base()


def get_db():
    """
    FastAPI dependency that provides a SQLAlchemy session.
    Usage:
        def some_endpoint(db: Session = Depends(get_db)):
            ...
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()