from typing import List, Tuple

import faiss
import numpy as np


def create_index(dimension: int) -> faiss.IndexFlatL2:
    """Create a FAISS index for L2 similarity search."""
    return faiss.IndexFlatL2(dimension)


def add_embeddings(index: faiss.IndexFlatL2, embeddings: List[List[float]]) -> None:
    """Add embeddings to the FAISS index."""
    if not embeddings:
        return
    vectors = np.array(embeddings).astype("float32")
    index.add(vectors)


def search(
    index: faiss.IndexFlatL2,
    query_vector: List[float],
    top_k: int = 5,
) -> Tuple[List[float], List[int]]:
    """Search the FAISS index and return distances and indices."""
    vector = np.array([query_vector]).astype("float32")
    distances, indices = index.search(vector, top_k)
    return distances[0].tolist(), indices[0].tolist()