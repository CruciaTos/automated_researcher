"""
app/models/base.py — SQLAlchemy declarative base and FastAPI DB dependency.

All ORM model files MUST import `Base` from here so their tables are
registered on `Base.metadata` before `create_all()` is called in main.py.
"""

from sqlalchemy.orm import Session, declarative_base

from app.config import SessionLocal

Base = declarative_base()


def get_db():
    """
    FastAPI dependency — yields a scoped database session.

    Guarantees the session is closed after every request, even on error.

    Usage::

        @router.get("/items/")
        def read_items(db: Session = Depends(get_db)):
            ...
    """
    db: Session = SessionLocal()
    try:
        yield db
    finally:
        db.close()
