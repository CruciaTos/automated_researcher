"""
app/models/document.py — Document ORM model.

Represents a single source document (Wikipedia article, arXiv paper, etc.)
fetched during the research pipeline's retrieval stage.
"""

from sqlalchemy import Column, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from app.models.base import Base


class Document(Base):
    __tablename__ = "documents"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)

    # Foreign key to the parent job
    job_id = Column(
        Integer,
        ForeignKey("research_jobs.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    # Source metadata
    title = Column(String(512), nullable=False, default="")
    url = Column(String(2048), nullable=False, default="")
    source_type = Column(String(64), nullable=False, default="unknown")
    # e.g. "wikipedia", "arxiv"

    # Textual content (intro / abstract / summary fetched at retrieval time)
    content = Column(Text, nullable=True)

    # Relationships
    chunks = relationship(
        "Chunk",
        back_populates="document",
        cascade="all, delete-orphan",
        lazy="select",
    )

    def __repr__(self) -> str:
        return (
            f"<Document id={self.id!r} job_id={self.job_id!r} "
            f"source_type={self.source_type!r} title={self.title!r:.40}>"
        )
