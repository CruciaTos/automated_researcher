"""
app/models/chunk.py — Chunk ORM model.

Represents a single text chunk derived from a Document during the
chunking stage of the research pipeline.

Chunks are the units fed to the embedding model and stored in FAISS.
The `chunk_index` field records the chunk's position within its parent
document so results can be presented in reading order.
"""

from sqlalchemy import Column, ForeignKey, Integer, Text
from sqlalchemy.orm import relationship

from app.models.base import Base


class Chunk(Base):
    __tablename__ = "chunks"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)

    # Foreign key to the parent document
    document_id = Column(
        Integer,
        ForeignKey("documents.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    # Position of this chunk within the document (0-based)
    chunk_index = Column(Integer, nullable=False, default=0)

    # The raw text of this chunk
    text = Column(Text, nullable=False)

    # Relationships
    document = relationship("Document", back_populates="chunks")

    def __repr__(self) -> str:
        preview = (self.text or "")[:40].replace("\n", " ")
        return (
            f"<Chunk id={self.id!r} document_id={self.document_id!r} "
            f"chunk_index={self.chunk_index!r} text={preview!r}>"
        )
