"""
app/models/research_job.py — ResearchJob ORM model.

Represents a single research request submitted by the user.
"""

from datetime import datetime

from sqlalchemy import Column, DateTime, Integer, String, Text

from app.models.base import Base


class ResearchJob(Base):
    __tablename__ = "research_jobs"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)

    # User-supplied fields
    topic = Column(String(512), nullable=False)
    depth_minutes = Column(Integer, nullable=False, default=5)

    # Pipeline tracking
    status = Column(
        String(64),
        nullable=False,
        default="queued",
        index=True,
        # Lifecycle values:
        #   queued → retrieving_sources → fetching_documents → chunking_documents
        #   → embedding_documents → drafting_outline → writing_report
        #   → completed | failed
    )
    progress = Column(Integer, nullable=False, default=0)  # 0–100

    # Output
    result_report = Column(Text, nullable=True)

    # Timestamps
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
    )

    def __repr__(self) -> str:
        return (
            f"<ResearchJob id={self.id!r} topic={self.topic!r} "
            f"status={self.status!r} progress={self.progress}>"
        )
