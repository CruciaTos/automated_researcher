"""
app/vector_store/faiss_store.py — FAISS index creation and retrieval helpers.

This module wraps the FAISS flat L2 index with a clean interface used by
the research pipeline. It is intentionally stateless — callers are
responsible for loading and persisting the index via `faiss.read_index` /
`faiss.write_index`.
"""

import logging
from typing import List, Tuple

import faiss
import numpy as np

logger = logging.getLogger(__name__)


def create_index(dimension: int) -> faiss.IndexFlatL2:
    """
    Create a new flat L2 FAISS index.

    Args:
        dimension: The dimensionality of the embedding vectors
                   (must match the output of the embedding model).

    Returns:
        An empty `faiss.IndexFlatL2` index.
    """
    if dimension <= 0:
        raise ValueError(f"dimension must be > 0, got {dimension}")
    index = faiss.IndexFlatL2(dimension)
    logger.debug("Created FAISS IndexFlatL2 with dimension=%d", dimension)
    return index


def add_embeddings(
    index: faiss.IndexFlatL2,
    embeddings: List[List[float]],
) -> None:
    """
    Add a list of embedding vectors to an existing FAISS index.

    Args:
        index:      A FAISS index created by `create_index`.
        embeddings: A list of float lists, each of length `dimension`.

    Raises:
        ValueError: If `embeddings` is empty.
    """
    if not embeddings:
        raise ValueError("embeddings list must not be empty")

    vectors = np.array(embeddings, dtype=np.float32)
    index.add(vectors)
    logger.debug("Added %d vectors to FAISS index (total: %d)", len(embeddings), index.ntotal)


def search_index(
    index: faiss.IndexFlatL2,
    query_embedding: List[float],
    top_k: int = 5,
) -> Tuple[List[int], List[float]]:
    """
    Search the FAISS index for the `top_k` nearest neighbours of a
    query embedding.

    Args:
        index:           A populated FAISS index.
        query_embedding: A single embedding vector (list of floats).
        top_k:           Number of nearest neighbours to return.

    Returns:
        A tuple of (indices, distances) where:
          - indices   is a list of integer positions in the index
          - distances is the corresponding list of L2 distances
                      (lower = more similar)

    Note:
        Returned indices may include ``-1`` if the index has fewer than
        ``top_k`` entries — callers should filter these out.
    """
    if index.ntotal == 0:
        logger.warning("search_index called on an empty FAISS index")
        return [], []

    query = np.array([query_embedding], dtype=np.float32)
    k = min(top_k, index.ntotal)
    distances, indices = index.search(query, k)

    flat_indices = [int(i) for i in indices[0] if i != -1]
    flat_distances = [float(d) for d, i in zip(distances[0], indices[0]) if i != -1]

    logger.debug(
        "FAISS search returned %d results (top_k=%d)", len(flat_indices), top_k
    )
    return flat_indices, flat_distances


def load_index(path: str) -> faiss.IndexFlatL2:
    """
    Load a persisted FAISS index from disk.

    Args:
        path: File path written by `faiss.write_index`.

    Returns:
        The loaded FAISS index.
    """
    index = faiss.read_index(path)
    logger.info("Loaded FAISS index from %s (ntotal=%d)", path, index.ntotal)
    return index
